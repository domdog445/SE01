package de.dorian.studium.se_1_ws17.u10.a3;

public class OeffnungsZeiten {

    public class TagesOeffnungsZeit {

        private int openHour;
        private int openMinute;

        private int closeHour = 24;
        private int closeMinute;

        private TagesOeffnungsZeit() {}

        public void setOpeningTime(int hour, int minute) {
            openHour = hour;
            openMinute = minute;
        }

        public void setCloseTime(int hour, int minute) {
            closeHour = hour;
            closeMinute = minute;
        }
    }

    private TagesOeffnungsZeit[] tagesOeffnungsZeiten = new TagesOeffnungsZeit[7];

    public OeffnungsZeiten() {
        for (int i = 0; i < tagesOeffnungsZeiten.length; i++) {
            tagesOeffnungsZeiten[i] = new TagesOeffnungsZeit(); // Standardmaeßig 24/7 geoeffnet
        }
    }

    public TagesOeffnungsZeit getTagesOeffnungsZeit(int tag) {
        return tagesOeffnungsZeiten[tag];
    }
}
