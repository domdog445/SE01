package de.dorian.studium.se_1_ws17.u10.a3;

import java.time.LocalDate;

public class Auto {

    private LocalDate einfahrtTime;
    private LocalDate ausfahrtTime;

    private final String kennzeichen;

    public Auto(LocalDate einfahrtTime, String kennzeichen) {
        this.einfahrtTime = einfahrtTime;
        this.kennzeichen = kennzeichen;
    }

    public LocalDate getEinfahrtTime() {
        return einfahrtTime;
    }

    public void setEinfahrtTime(LocalDate einfahrtTime) {
        this.einfahrtTime = einfahrtTime;
    }

    public LocalDate getAusfahrtTime() {
        return ausfahrtTime;
    }

    public void setAusfahrtTime(LocalDate ausfahrtTime) {
        this.ausfahrtTime = ausfahrtTime;
    }

    public String getKennzeichen() {
        return kennzeichen;
    }
}
