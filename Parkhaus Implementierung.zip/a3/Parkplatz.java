package de.dorian.studium.se_1_ws17.u10.a3;


public class Parkplatz {

    private final int nummer;
    private Auto auto;

    public Parkplatz(int nummer) {
        this.nummer = nummer;
    }

    public int getNummer() {
        return nummer;
    }

    public Auto getAuto() {
        return auto;
    }

    public void setAuto(Auto auto) {
        this.auto = auto;
    }

    public boolean isBelegt() {
        return auto != null;
    }
}
