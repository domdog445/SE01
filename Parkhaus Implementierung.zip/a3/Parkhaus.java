package de.dorian.studium.se_1_ws17.u10.a3;

public class Parkhaus {

    private String name;
    private float preis = 2; // Standardpreis 2 EUR
    private Adresse adresse;
    private Parkplatz[] parkplaetze = new Parkplatz[200];

    private boolean geoeffnet;
    private OeffnungsZeiten oeffnungsZeiten = new OeffnungsZeiten();

    public Parkhaus(String name, Adresse adresse) {
        this.name = name;
        this.adresse = adresse;
        for (int i = 0; i < parkplaetze.length; i++) {
            parkplaetze[i] = new Parkplatz(i);
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getPreis() {
        return preis;
    }

    public void setPreis(float preis) {
        this.preis = preis;
    }

    public Adresse getAdresse() {
        return adresse;
    }

    public void setAdresse(Adresse adresse) {
        this.adresse = adresse;
    }

    public Parkplatz[] getParkplaetze() {
        return parkplaetze;
    }

    public boolean isGeoeffnet() {
        return geoeffnet;
    }

    public void setGeoeffnet(boolean geoeffnet) {
        this.geoeffnet = geoeffnet;
    }

    public OeffnungsZeiten getOeffnungsZeiten() {
        return oeffnungsZeiten;
    }
}
