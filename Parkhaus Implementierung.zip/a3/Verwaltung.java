package de.dorian.studium.se_1_ws17.u10.a3;

import de.dorian.studium.se_1_ws17.u10.a3.statistik.EreignisTyp;

public class Verwaltung {

    public void setGeoeffnet(Parkhaus parkhaus, boolean geoeffnet) {
        parkhaus.setGeoeffnet(geoeffnet);
    }

    public boolean isGeoeffnet(Parkhaus parkhaus) {
        return parkhaus.isGeoeffnet();
    }

    public OeffnungsZeiten getOeffnungsZeiten(Parkhaus parkhaus) {
        return parkhaus.getOeffnungsZeiten();
    }

    public float getStundenPreis(Parkhaus parkhaus) {
        return parkhaus.getPreis();
    }

    public void setStundenPreis(Parkhaus parkhaus, float stundenPreis) {
        parkhaus.setPreis(stundenPreis);
    }

    public Statistik getAuslastungStatistik() {
        return new Statistik(null, EreignisTyp.AUSLASTUNG);
    }

    public Statistik getEinnahmenStatistik() {
        return new Statistik(null, EreignisTyp.EINNAHMEN);
    }
}
