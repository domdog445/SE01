package de.dorian.studium.se_1_ws17.u10.a3.statistik;

import java.time.LocalDate;

public class Ereignis {

    private final Number wert;

    private final LocalDate timestamp;
    public Ereignis(LocalDate timestamp, Number ereignis) {
        this.timestamp = timestamp;
        this.wert = ereignis;
    }

    public LocalDate getTimestamp() {
        return timestamp;
    }

    public Number getWert() {
        return wert;
    }
}
