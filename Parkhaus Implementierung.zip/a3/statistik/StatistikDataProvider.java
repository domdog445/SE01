package de.dorian.studium.se_1_ws17.u10.a3.statistik;

import java.time.LocalDate;
import java.util.Set;

public interface StatistikDataProvider {

    Set<Ereignis> getStatistikData(EreignisTyp ereignisTyp, LocalDate start, LocalDate end);
}
