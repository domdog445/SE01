package de.dorian.studium.se_1_ws17.u10.a3.statistik;

public enum EreignisTyp {

    EINNAHMEN,
    AUSLASTUNG
}
