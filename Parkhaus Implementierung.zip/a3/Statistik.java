package de.dorian.studium.se_1_ws17.u10.a3;

import de.dorian.studium.se_1_ws17.u10.a3.statistik.Ereignis;
import de.dorian.studium.se_1_ws17.u10.a3.statistik.EreignisTyp;
import de.dorian.studium.se_1_ws17.u10.a3.statistik.StatistikDataProvider;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

public class Statistik {

    private LocalDate startDate;
    private LocalDate endDate = LocalDate.now();

    private Set<Ereignis> ereignisse;

    public Statistik(StatistikDataProvider dataProvider, EreignisTyp ereignisTyp) {
        this(dataProvider, ereignisTyp, LocalDate.now().minusMonths(6), LocalDate.now()); // Statistik der letzten 6 Monate
    }

    public Statistik(StatistikDataProvider dataProvider, EreignisTyp ereignisTyp, LocalDate startDate) {
        this(dataProvider, ereignisTyp, startDate, LocalDate.now());
    }

    public Statistik(StatistikDataProvider dataProvider, EreignisTyp ereignisTyp, LocalDate startDate, LocalDate endDate) {
        this.startDate = startDate;
        this.endDate = endDate;
        ereignisse = dataProvider.getStatistikData(ereignisTyp, startDate, endDate);
    }

    public Set<Ereignis> getMonatsSummen(int jahr) {
        Set<Ereignis> jahresEreinisse = ereignisse.stream().filter(e -> e.getTimestamp().getYear() == jahr).collect(Collectors.toSet());
        Set<Ereignis> monatsEreignisse = new HashSet<>(12);
        for (int i = 1; i <= 12; i++) {
            final int finalI = i;
            monatsEreignisse.add(jahresEreinisse.stream().filter(
                    e -> e.getTimestamp().getMonth().getValue() == finalI
            ).reduce(
                    (a, b) -> new Ereignis(LocalDate.of(jahr, finalI, 1), a.getWert().doubleValue() + b.getWert().doubleValue())
            ).orElse(new Ereignis(LocalDate.of(jahr, i, 1), 0)));
        }
        return monatsEreignisse;
    }

    public Set<Ereignis> getMonatsDurchschnitt(int jahr) {
        Set<Ereignis> jahresEreinisse = ereignisse.stream().filter(e -> e.getTimestamp().getYear() == jahr).collect(Collectors.toSet());
        Set<Ereignis> monatsEreignisse = new HashSet<>(12);
        for (int i = 1; i <= 12; i++) {
            final int finalI = i;
            monatsEreignisse.add(
                    new Ereignis(
                            LocalDate.of(jahr, i, 1),
                            jahresEreinisse.stream().filter(
                                    e -> e.getTimestamp().getMonth().getValue() == finalI
                            )
                            .mapToDouble(e -> (double) e.getWert())
                            .average().orElse(0)
                    )
            );
        }
        return monatsEreignisse;
    }
}
