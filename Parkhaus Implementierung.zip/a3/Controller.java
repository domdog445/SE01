package de.dorian.studium.se_1_ws17.u10.a3;

import java.time.LocalDate;

public class Controller {

    private Parkhaus parkhaus = new Parkhaus("Parkhaus", new Adresse("Wendelstrasse", "8", "53474", "Bad Neuenahr-Ahrweiler"));

    private Verwaltung verwaltung = new Verwaltung();

    public void autoEinparken(Auto auto, int parkplatzNr) {
        Parkplatz parkplatz = parkhaus.getParkplaetze()[parkplatzNr];

        if (!parkplatz.isBelegt()) {
            auto.setEinfahrtTime(LocalDate.now());
            parkplatz.setAuto(auto);
        } else {
            throw new IllegalArgumentException("Parkplatz Nr. " + parkplatzNr + " ist belegt.");
        }
    }

    public void autoAusparken(Auto auto) {
        for (int i = 0; i < parkhaus.getParkplaetze().length; i++) {
            if (parkhaus.getParkplaetze()[i].getAuto() == auto) {
                parkhaus.getParkplaetze()[i].setAuto(null);
            }
        }

        throw new IllegalArgumentException("Auto steht nicht im Parkhaus.");
    }
}
