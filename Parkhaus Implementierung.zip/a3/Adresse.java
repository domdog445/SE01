package de.dorian.studium.se_1_ws17.u10.a3;

public class Adresse {

    private final String strasse;
    private final String hausnummer;
    private final String postleitzahl;
    private final String ort;

    public Adresse(String strasse, String hausnummer, String postleitzahl, String ort) {
        this.strasse = strasse;
        this.hausnummer = hausnummer;
        this.postleitzahl = postleitzahl;
        this.ort = ort;
    }

    public String getStrasse() {
        return strasse;
    }

    public String getHausnummer() {
        return hausnummer;
    }

    public String getPostleitzahl() {
        return postleitzahl;
    }

    public String getOrt() {
        return ort;
    }
}
